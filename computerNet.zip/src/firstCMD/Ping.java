package firstCMD;

import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ping {
//-i2 -n8
    public static void main(String[] args) throws Exception {
        JFrame jf = new JFrame("firstCMD.Ping");
        JPanel jp = new JPanel();
        JLayeredPane layeredPane = new JLayeredPane();
        ImageIcon image = new ImageIcon("bgs/1.jpg");
        jp.setBounds(0, 0, image.getIconWidth(), image.getIconHeight());//让图片充满整个面板
        JLabel bg = new JLabel(image);
        JLabel jl = new JLabel("Ping命令");
        JButton jb = new JButton("ping");
//        JLabel jl1 = new JLabel("Ping地址");
//        JButton jb1 = new JButton("ping");
        JTextField jt = new JTextField();
        jl.setBounds(250,10,500,40);
        jt.setBounds(100, 105, 200, 30);
        jb.setBounds(400,95,150,50);
        Font titleFont = new Font("宋体",Font.BOLD,50);
        jl.setFont(titleFont);
        Font font = new Font("宋体", Font.BOLD, 15);
        jl.setFont(font);
        jb.setFont(font);
        jb.addActionListener(arg0 ->{
//            Scanner input = new Scanner(System.in);

//                String command = input.nextLine();
                String command = jt.getText();
                execProgramC("ping "+command);

                });
        jp.add(bg);
        layeredPane.add(jp, JLayeredPane.DEFAULT_LAYER);
        layeredPane.add(jl, JLayeredPane.MODAL_LAYER);
        layeredPane.add(jt, JLayeredPane.MODAL_LAYER);
        layeredPane.add(jb, JLayeredPane.MODAL_LAYER);
        jf.setLayeredPane(layeredPane);
        jf.setSize(600, 250);
        jf.setLocation(400, 250);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jf.setResizable(false);
        jf.setVisible(true);

//        String ipAddress = "127.0.0.1";
////        System.out.println(ping(ipAddress));
////        ping02(ipAddress);
//        System.out.println(ping(ipAddress, 3, 500));

//        Scanner input = new Scanner(System.in);
//        while (true) {
//            String command = input.nextLine();
//            execProgramC(command);
//        }

    }

    public static void execProgramC(String command) {
        try {
            Process process = Runtime.getRuntime().exec(command);
            BufferedReader br = new BufferedReader(new InputStreamReader(process.getInputStream(), Charset.forName("GBK")));
            String line = null;
            while ((line = br.readLine()) != null)
                System.out.println(line); // Hello World.
            process.waitFor();
            System.out.println("Process exitValue: " + process.exitValue());
        } catch (Throwable t) {
//            t.printStackTrace();
        }
    }
}
