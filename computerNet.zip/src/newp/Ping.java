package newp;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

public class Ping {
    // 定义类Ping
    private int timeOut;// 定义私有整型变量timeout
    private Timer t;// 声明一个Timer类的对象t，但未分配内存

    public Ping(int timeOut) {// 构造方法 进行初始化
        this.timeOut = timeOut;
        t = new Timer();// 给对象t分配内存。
    }

    public String pingRang(String from, String to) { // 确定ping地址的范围
        int[] ipFrom = stringArToIntAr(from.split("\\."));// 整形数组变量用来接收起始ip地址
        int[] ipTo = stringArToIntAr(to.split("\\."));// 接收终止的ip地址
        String output = "";// 定义字符串型变量output用来接收结果
        ipTo[3] = ipTo[3] + 1;// ipTo 数组里的地址的第四个元素加1
        while (!matchIP(ipFrom, ipTo)) {//
            output += "Pinging:" + printIP(ipFrom);// output变量用来接收printIP（ipFrom）的返回结果
            output += "(" + ping(printIP(ipFrom)) + ") Response Time:"
                    + responseTime() + "\n";// 再接收ping(printIP(ipFrom))的结果
            increaseIPrange(ipFrom, ipFrom.length - 1);// 调用increaseIPrange(),传入的参数为ipFrom起始地址、ipFrom数组长度-1，即为3
        }
        return output;
    }

    private void increaseIPrange(int[] ipFrom, int curBit) {// 逐渐增加IP地址的范围,curBit表示ip地址的最后一位
        ipFrom[curBit] += 1;// ipFrom[3],即表示最后一位每次加1
        if (ipFrom[curBit] > 255) { // 如果最后一位大于255
            ipFrom[curBit] = 0; // 则重新置为0
            if (curBit > 0) // 如果大于0
                increaseIPrange(ipFrom, curBit - 1);// 则再次调用本方法，将增加位置改为ip地址的第三位
        }
    }

    private boolean matchIP(int[] from, int[] to) {// 判断起始ip地址和终止ip地址是否在同一个网段中
        for (int c = 0; c < from.length; c++) {
            if (from[c] != to[c]) {
                return false;
            }
        }
        return true;

    }

    private String printIP(int[] ip)// 将数组形式存放的ip地址转换成一般ip地址格式后打印出来
    {
        String ipVal = "";
        for (int c = 0; c < ip.length; c++)// 循环输出ip数组中的每个元素，同时加符号"."，得到ip地址格式的字符串
        {
            ipVal += ip[c];// ipVal=ipVal+ip[c]
            if (c < ip.length - 1)
                ipVal += ".";// 输出IP地址的格式

        }
        return ipVal;
    }

    private int[] stringArToIntAr(String[] ar)// 实现字符串数组转换为整形数组输出
    {
        int[] result = new int[ar.length];
        for (int a = 0; a < ar.length; a++) {
            result[a] = Integer.parseInt(ar[a]);
        }
        return result;
    }

    public String ping(String host)// 获取主机地址名
    {
        try {
            t.start();// 通过t调用Timer类中的start（）方法
            InetAddress address = InetAddress.getByName(host);// 给出主机的名称，决定主机的IP地址
            String retVal = pingAddress(address);
            t.end();
            return retVal;
        } catch (UnknownHostException e)// UnknownHostException - 如果找不到 host 的
        // IP 地址
        {
            return "指定主机没有找到";
        }
    }

    public String ping(byte[] host)// 将给定的ip地址创建成InetAddress 对象
    {
        try {
            t.start();
            InetAddress address = InetAddress.getByAddress(host);// 给出原始的ip地址，返回一个InetAddress对象
            String retVal = pingAddress(address);// 调用pingAddress()方法，实现ping功能，并取得返回结果
            t.end();
            return retVal;// 返回结果
        } catch (UnknownHostException e)// 指示主机 IP 地址无法确定而抛出的异常。
        {
            return "指定主机没有找到";
        }
    }

    private String pingAddress(InetAddress address) {// 实现ping命令功能，返回字符串格式的原始 IP
        // 地址。

        try {// 可能会抛出异常
            if (address.isReachable(timeOut))// 调用isReachable（）方法，如果测试可以达到address地址
                return "连接成功";// 则返回连接成功
            else
                return "连接超时";
        } catch (IOException e) {// 当发生某种 I/O 异常时，捕获此异常。
            return "不可达";
        }
    }

    public long responseTime() {// 响应时间的长度
        return t.duration();// 调用Timer类的duration()方法计算响应时间。
    }

    public static void main(String args[]) {// main主函数
        Ping pt = new Ping(2000);// 设置响应时间的最大时间
        System.out.println(pt.pingRang("10.64.41.41", "10.64.41.42"));// 需要测试的ip地址范围
    }

}
