package newp;

final class Timer// 定义一个final类Timer
{
    private long start;
    private long end;

    public void start()// 开始时间
    {
        reset();// 调用reset（）方法重置start和end
        System.gc();// 然后运行垃圾回收，释放所占用内存
        start = System.currentTimeMillis();// 记录开始时间为currentTimeMillis当前时间
    }

    public void end()// 结束时间
    {
        System.gc();
        end = System.currentTimeMillis();
    }

    public long duration()// 计算响应时间的方法
    {
        return (end - start);
    }

    public void reset()// 重置开始和结束时间
    {
        start = 0;
        end = 0;
    }
}

